import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Users, LogOut, Menu, X, ShieldCheck, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Auth from './pages/Auth';
import Dashboard from './pages/Dashboard';
import StudentList from './pages/StudentList';
import BehaviorHistory from './pages/BehaviorHistory';
import { User } from './types';

function Layout({ user, onLogout, children }: { user: User, onLogout: () => void, children: React.ReactNode }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'แดชบอร์ด', icon: <LayoutDashboard className="w-5 h-5" /> },
    { path: '/students', label: 'รายชื่อนักเรียน', icon: <Users className="w-5 h-5" /> },
    { path: '/history', label: 'ประวัติคะแนน', icon: <FileText className="w-5 h-5" /> },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 p-6">
        <div className="flex items-center space-x-3 mb-10 px-2">
          <div className="bg-indigo-600 p-2 rounded-lg">
            <ShieldCheck className="w-6 h-6 text-white" />
          </div>
          <span className="font-bold text-slate-800 tracking-tight">Conduct System</span>
        </div>

        <nav className="flex-1 space-y-2">
          {navItems.map(item => (
            <Link 
              key={item.path}
              to={item.path}
              className={`flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
                location.pathname === item.path 
                  ? 'bg-indigo-50 text-indigo-600 font-bold' 
                  : 'text-slate-500 hover:bg-slate-50'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="mt-auto pt-6 border-t border-slate-100">
          <div className="px-4 py-3 mb-4 bg-slate-50 rounded-xl">
            <p className="text-xs text-slate-400 font-medium uppercase tracking-wider mb-1">ผู้ใช้งาน</p>
            <p className="font-bold text-slate-800 truncate">{user.name}</p>
            <p className="text-xs text-indigo-600 font-semibold">{user.role === 'admin' ? 'ผู้ดูแลระบบ' : 'ครูผู้สอน'}</p>
          </div>
          <button 
            onClick={onLogout}
            className="w-full flex items-center space-x-3 px-4 py-3 text-rose-600 hover:bg-rose-50 rounded-xl transition-all"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-bold">ออกจากระบบ</span>
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="md:hidden bg-white border-b border-slate-200 p-4 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-6 h-6 text-indigo-600" />
          <span className="font-bold text-slate-800">Conduct System</span>
        </div>
        <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-slate-600">
          {isMenuOpen ? <X /> : <Menu />}
        </button>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden fixed inset-0 top-[65px] bg-white z-30 p-6 flex flex-col"
          >
            <nav className="space-y-4">
              {navItems.map(item => (
                <Link 
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`flex items-center space-x-4 p-4 rounded-2xl ${
                    location.pathname === item.path ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600'
                  }`}
                >
                  {item.icon}
                  <span className="text-lg font-bold">{item.label}</span>
                </Link>
              ))}
            </nav>
            <button 
              onClick={onLogout}
              className="mt-auto flex items-center space-x-4 p-4 text-rose-600 bg-rose-50 rounded-2xl"
            >
              <LogOut className="w-6 h-6" />
              <span className="text-lg font-bold">ออกจากระบบ</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 lg:p-12 overflow-y-auto">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          {children}
        </motion.div>
      </main>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    const token = localStorage.getItem('token');
    if (savedUser && token) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const handleLogin = (user: User, token: string) => {
    setUser(user);
    localStorage.setItem('user', JSON.stringify(user));
    localStorage.setItem('token', token);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
    localStorage.removeItem('token');
  };

  if (loading) return null;

  if (!user) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <BrowserRouter>
      <Layout user={user} onLogout={handleLogout}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/students" element={<StudentList userRole={user.role} />} />
          <Route path="/history" element={<BehaviorHistory />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
