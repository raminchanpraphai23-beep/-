export interface User {
  id: number;
  username: string;
  name: string;
  role: 'admin' | 'teacher';
}

export interface Student {
  id: number;
  student_id: string;
  name: string;
  grade: string;
  score: number;
}

export interface ScoreHistory {
  id: number;
  student_id: string;
  score_change: number;
  reason: string;
  teacher_id: number;
  teacher_name: string;
  created_at: string;
}

export interface DashboardStats {
  totalStudents: number;
  avgScore: number;
  lowScores: number;
  scoreDistribution: { range: string; count: number }[];
}
