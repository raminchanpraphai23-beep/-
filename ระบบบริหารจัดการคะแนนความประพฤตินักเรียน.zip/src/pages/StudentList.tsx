import React, { useState, useEffect } from 'react';
import { Search, Plus, Minus, FileText, UserPlus, Edit2, Trash2, History, X, User } from 'lucide-react';
import api from '../services/api';
import { Student, ScoreHistory, User as UserType } from '../types';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

export default function StudentList({ userRole }: { userRole: string }) {
  const [students, setStudents] = useState<Student[]>([]);
  const [search, setSearch] = useState('');
  const [gradeFilter, setGradeFilter] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState<Student | null>(null);
  const [showScoreModal, setShowScoreModal] = useState<{ student: Student, type: 'plus' | 'minus' } | null>(null);
  const [showHistoryModal, setShowHistoryModal] = useState<Student | null>(null);
  const [studentHistory, setStudentHistory] = useState<ScoreHistory[]>([]);
  
  const [newStudent, setNewStudent] = useState({ student_id: '', name: '', grade: '' });
  const [scoreData, setScoreData] = useState({ amount: 5, reason: '' });

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    const res = await api.get('/students');
    setStudents(res.data);
  };

  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.post('/students', newStudent);
      setShowAddModal(false);
      setNewStudent({ student_id: '', name: '', grade: '' });
      fetchStudents();
    } catch (err) {
      alert('เกิดข้อผิดพลาด: รหัสนักเรียนอาจซ้ำกัน');
    }
  };

  const handleEditStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!showEditModal) return;
    try {
      await api.put(`/students/${showEditModal.id}`, showEditModal);
      setShowEditModal(null);
      fetchStudents();
    } catch (err) {
      alert('เกิดข้อผิดพลาดในการแก้ไขข้อมูล');
    }
  };

  const handleDeleteStudent = async (id: number) => {
    if (!confirm('ยืนยันการลบข้อมูลนักเรียน? ข้อมูลประวัติคะแนนทั้งหมดจะถูกลบไปด้วย')) return;
    try {
      await api.delete(`/students/${id}`);
      fetchStudents();
    } catch (err) {
      alert('เกิดข้อผิดพลาดในการลบข้อมูล');
    }
  };

  const handleUpdateScore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!showScoreModal) return;
    
    const change = showScoreModal.type === 'plus' ? scoreData.amount : -scoreData.amount;
    try {
      await api.post('/scores/update', {
        student_id: showScoreModal.student.student_id,
        score_change: change,
        reason: scoreData.reason
      });
      setShowScoreModal(null);
      setScoreData({ amount: 5, reason: '' });
      fetchStudents();
    } catch (err) {
      alert('เกิดข้อผิดพลาดในการอัปเดตคะแนน');
    }
  };

  const viewHistory = async (student: Student) => {
    setShowHistoryModal(student);
    const res = await api.get(`/scores/history/${student.student_id}`);
    setStudentHistory(res.data);
  };

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.text('Report: Student Conduct Scores', 14, 15);
    doc.text(`Date: ${new Date().toLocaleDateString('th-TH')}`, 14, 25);

    const tableData = filteredStudents.map(s => [s.student_id, s.name, s.grade, s.score]);
    
    (doc as any).autoTable({
      head: [['ID', 'Name', 'Grade', 'Score']],
      body: tableData,
      startY: 30,
    });

    doc.save('student-scores.pdf');
  };

  const grades = Array.from(new Set(students.map(s => s.grade))).sort();

  const filteredStudents = students.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(search.toLowerCase()) || 
                         s.student_id.includes(search);
    const matchesGrade = gradeFilter === '' || s.grade === gradeFilter;
    return matchesSearch && matchesGrade;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-800">รายชื่อนักเรียน</h1>
        <div className="flex items-center space-x-2">
          <button 
            onClick={exportPDF}
            className="flex items-center space-x-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors"
          >
            <FileText className="w-4 h-4" />
            <span>ส่งออก PDF</span>
          </button>
          {userRole === 'admin' && (
            <button 
              onClick={() => setShowAddModal(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors"
            >
              <UserPlus className="w-4 h-4" />
              <span>เพิ่มนักเรียน</span>
            </button>
          )}
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input 
              type="text" 
              placeholder="ค้นหาชื่อหรือรหัสนักเรียน..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 transition-all"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="w-full md:w-48">
            <select 
              className="w-full px-4 py-2 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 transition-all"
              value={gradeFilter}
              onChange={(e) => setGradeFilter(e.target.value)}
            >
              <option value="">ทุกชั้นเรียน</option>
              {grades.map(g => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-sm uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4 font-semibold">รหัส</th>
                <th className="px-6 py-4 font-semibold">ชื่อ-นามสกุล</th>
                <th className="px-6 py-4 font-semibold">ชั้นเรียน</th>
                <th className="px-6 py-4 font-semibold">คะแนน</th>
                <th className="px-6 py-4 font-semibold text-right">จัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.map(student => (
                <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 font-medium text-slate-600">{student.student_id}</td>
                  <td className="px-6 py-4 font-semibold text-slate-800">{student.name}</td>
                  <td className="px-6 py-4 text-slate-600">{student.grade}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                      student.score >= 80 ? 'bg-emerald-100 text-emerald-700' :
                      student.score >= 60 ? 'bg-blue-100 text-blue-700' :
                      'bg-rose-100 text-rose-700'
                    }`}>
                      {student.score}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end space-x-1">
                      <button 
                        onClick={() => setShowScoreModal({ student, type: 'plus' })}
                        className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                        title="บวกคะแนน"
                      >
                        <Plus className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => setShowScoreModal({ student, type: 'minus' })}
                        className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="หักคะแนน"
                      >
                        <Minus className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => viewHistory(student)}
                        className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        title="ดูประวัติ"
                      >
                        <History className="w-5 h-5" />
                      </button>
                      {userRole === 'admin' && (
                        <>
                          <button 
                            onClick={() => setShowEditModal(student)}
                            className="p-2 text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                            title="แก้ไข"
                          >
                            <Edit2 className="w-5 h-5" />
                          </button>
                          <button 
                            onClick={() => handleDeleteStudent(student.id)}
                            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="ลบ"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Student Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
            <h2 className="text-xl font-bold mb-4">เพิ่มนักเรียนใหม่</h2>
            <form onSubmit={handleAddStudent} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">รหัสนักเรียน</label>
                <input 
                  required
                  type="text" 
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={newStudent.student_id}
                  onChange={e => setNewStudent({...newStudent, student_id: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ชื่อ-นามสกุล</label>
                <input 
                  required
                  type="text" 
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={newStudent.name}
                  onChange={e => setNewStudent({...newStudent, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ชั้นเรียน</label>
                <input 
                  required
                  type="text" 
                  placeholder="เช่น ม.1/1"
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={newStudent.grade}
                  onChange={e => setNewStudent({...newStudent, grade: e.target.value})}
                />
              </div>
              <div className="flex space-x-3 pt-2">
                <button 
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-colors"
                >
                  ยกเลิก
                </button>
                <button 
                  type="submit"
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors"
                >
                  บันทึก
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Student Modal */}
      {showEditModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
            <h2 className="text-xl font-bold mb-4">แก้ไขข้อมูลนักเรียน</h2>
            <form onSubmit={handleEditStudent} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">รหัสนักเรียน</label>
                <input 
                  required
                  type="text" 
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={showEditModal.student_id}
                  onChange={e => setShowEditModal({...showEditModal, student_id: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ชื่อ-นามสกุล</label>
                <input 
                  required
                  type="text" 
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={showEditModal.name}
                  onChange={e => setShowEditModal({...showEditModal, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ชั้นเรียน</label>
                <input 
                  required
                  type="text" 
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={showEditModal.grade}
                  onChange={e => setShowEditModal({...showEditModal, grade: e.target.value})}
                />
              </div>
              <div className="flex space-x-3 pt-2">
                <button 
                  type="button"
                  onClick={() => setShowEditModal(null)}
                  className="flex-1 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-colors"
                >
                  ยกเลิก
                </button>
                <button 
                  type="submit"
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors"
                >
                  บันทึกการแก้ไข
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Score Management Modal */}
      {showScoreModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
            <h2 className="text-xl font-bold mb-1">
              {showScoreModal.type === 'plus' ? 'บวกคะแนน' : 'หักคะแนน'}
            </h2>
            <p className="text-slate-500 mb-4">{showScoreModal.student.name} ({showScoreModal.student.student_id})</p>
            <form onSubmit={handleUpdateScore} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">จำนวนคะแนน</label>
                <input 
                  required
                  type="number" 
                  min="1"
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={scoreData.amount}
                  onChange={e => setScoreData({...scoreData, amount: parseInt(e.target.value)})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">เหตุผล / บันทึกเพิ่มเติม</label>
                <textarea 
                  required
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none h-24"
                  value={scoreData.reason}
                  onChange={e => setScoreData({...scoreData, reason: e.target.value})}
                ></textarea>
              </div>
              <div className="flex space-x-3 pt-2">
                <button 
                  type="button"
                  onClick={() => setShowScoreModal(null)}
                  className="flex-1 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-colors"
                >
                  ยกเลิก
                </button>
                <button 
                  type="submit"
                  className={`flex-1 px-4 py-2 text-white rounded-xl transition-colors ${
                    showScoreModal.type === 'plus' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  ยืนยัน
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* History Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-2xl shadow-xl max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold">ประวัติคะแนนความประพฤติ</h2>
                <p className="text-slate-500">{showHistoryModal.name} ({showHistoryModal.student_id})</p>
              </div>
              <button onClick={() => setShowHistoryModal(null)} className="p-2 hover:bg-slate-100 rounded-full">
                <X className="w-6 h-6 text-slate-400" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto pr-2">
              {studentHistory.length === 0 ? (
                <div className="py-12 text-center text-slate-400 italic">ไม่พบประวัติการปรับคะแนน</div>
              ) : (
                <div className="space-y-4">
                  {studentHistory.map(item => (
                    <div key={item.id} className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                      <div className="flex items-center justify-between mb-2">
                        <span className={`font-bold ${item.score_change > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {item.score_change > 0 ? `+${item.score_change}` : item.score_change} คะแนน
                        </span>
                        <span className="text-xs text-slate-400">
                          {new Date(item.created_at).toLocaleString('th-TH')}
                        </span>
                      </div>
                      <p className="text-slate-700 mb-2">{item.reason}</p>
                      <div className="text-xs text-slate-500 flex items-center">
                        <User className="w-3 h-3 mr-1" />
                        บันทึกโดย: {item.teacher_name}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
