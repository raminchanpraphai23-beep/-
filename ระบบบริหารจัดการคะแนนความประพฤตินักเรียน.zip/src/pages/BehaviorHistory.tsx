import React, { useState, useEffect } from 'react';
import { Search, Filter, Calendar, User, ArrowUpRight, ArrowDownRight, FileText } from 'lucide-react';
import api from '../services/api';
import { ScoreHistory, User as UserType } from '../types';

export default function BehaviorHistory() {
  const [history, setHistory] = useState<ScoreHistory[]>([]);
  const [teachers, setTeachers] = useState<{ id: number, name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [filters, setFilters] = useState({
    student_id: '',
    teacher_id: '',
    type: '',
    start_date: '',
    end_date: ''
  });

  useEffect(() => {
    fetchTeachers();
    fetchHistory();
  }, []);

  const fetchTeachers = async () => {
    const res = await api.get('/teachers');
    setTeachers(res.data);
  };

  const fetchHistory = async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (filters.student_id) params.append('student_id', filters.student_id);
    if (filters.teacher_id) params.append('teacher_id', filters.teacher_id);
    if (filters.type) params.append('type', filters.type);
    if (filters.start_date) params.append('start_date', filters.start_date);
    if (filters.end_date) params.append('end_date', filters.end_date);

    const res = await api.get(`/scores/history?${params.toString()}`);
    setHistory(res.data);
    setLoading(false);
  };

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-800">ประวัติคะแนนความประพฤติ</h1>
      </div>

      {/* Filters */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 space-y-4">
        <div className="flex items-center space-x-2 text-slate-800 font-semibold mb-2">
          <Filter className="w-5 h-5" />
          <span>ตัวกรองข้อมูล</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-1">รหัสนักเรียน</label>
            <input 
              type="text" 
              name="student_id"
              placeholder="ค้นหารหัส..."
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
              value={filters.student_id}
              onChange={handleFilterChange}
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-1">ผู้บันทึก (ครู)</label>
            <select 
              name="teacher_id"
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
              value={filters.teacher_id}
              onChange={handleFilterChange}
            >
              <option value="">ทั้งหมด</option>
              {teachers.map(t => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-1">ประเภทคะแนน</label>
            <select 
              name="type"
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
              value={filters.type}
              onChange={handleFilterChange}
            >
              <option value="">ทั้งหมด</option>
              <option value="positive">บวกคะแนน (+)</option>
              <option value="negative">หักคะแนน (-)</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-1">วันที่เริ่มต้น</label>
            <input 
              type="date" 
              name="start_date"
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
              value={filters.start_date}
              onChange={handleFilterChange}
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-1">วันที่สิ้นสุด</label>
            <input 
              type="date" 
              name="end_date"
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
              value={filters.end_date}
              onChange={handleFilterChange}
            />
          </div>
        </div>
        
        <div className="flex justify-end">
          <button 
            onClick={fetchHistory}
            className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all"
          >
            ค้นหาข้อมูล
          </button>
        </div>
      </div>

      {/* History Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-500">กำลังโหลดข้อมูล...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-500 text-sm uppercase tracking-wider">
                <tr>
                  <th className="px-6 py-4 font-semibold">วันที่/เวลา</th>
                  <th className="px-6 py-4 font-semibold">นักเรียน</th>
                  <th className="px-6 py-4 font-semibold">คะแนน</th>
                  <th className="px-6 py-4 font-semibold">เหตุผล</th>
                  <th className="px-6 py-4 font-semibold">ผู้บันทึก</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {history.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center text-slate-400 italic">ไม่พบข้อมูลประวัติ</td>
                  </tr>
                ) : (
                  history.map(item => (
                    <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 text-sm text-slate-500">
                        {new Date(item.created_at).toLocaleString('th-TH')}
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-semibold text-slate-800">{(item as any).student_name}</div>
                        <div className="text-xs text-slate-500">{(item as any).student_id} • {(item as any).student_grade}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className={`flex items-center font-bold ${item.score_change > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {item.score_change > 0 ? <ArrowUpRight className="w-4 h-4 mr-1" /> : <ArrowDownRight className="w-4 h-4 mr-1" />}
                          {item.score_change > 0 ? `+${item.score_change}` : item.score_change}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-600 max-w-xs truncate" title={item.reason}>
                        {item.reason}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-6 h-6 bg-slate-200 rounded-full flex items-center justify-center">
                            <User className="w-3 h-3 text-slate-500" />
                          </div>
                          <span className="text-sm text-slate-600">{item.teacher_name}</span>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
